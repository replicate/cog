def greet(name: str) -> str:
    return f'Hello {name}'


def my_sum(a: int, b:int) -> int:
    return a + b

