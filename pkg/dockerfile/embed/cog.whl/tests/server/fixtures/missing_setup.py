class Predictor:
    # This predictor has no setup method

    def predict(self):
        print("did predict")
