import sys

class Predictor:
    def setup(self):
        print("did setup")

    def predict(self):
        sys.exit(1)
